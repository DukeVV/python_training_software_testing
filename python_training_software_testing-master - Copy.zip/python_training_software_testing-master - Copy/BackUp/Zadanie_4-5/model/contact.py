
class Contact:


    def __init__(self, firstname, middlename, lastname):
        self.firstname = firstname
        self.middlename = middlename
        self.lastname = lastname





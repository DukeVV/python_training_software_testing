
class Group:

    def __init__(self, name, header, footer):
        self.name = name
        self.header = header
        self.footer = footer
